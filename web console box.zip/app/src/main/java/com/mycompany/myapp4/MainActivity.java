package com.mycompany.myapp4;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.entity.*;
import org.apache.http.client.methods.*;
import org.apache.http.impl.client.*;
import org.apache.http.message.*;
import java.security.*;
public class MainActivity extends Activity {
	WebView wb;
	ProgressBar progress ;
	EditText editTextName;
	String GetName;
	Button buttonSubmit ;
	String DataParseUrl = "http://melkisuleman882.000webhostapp.com/console/console.php";
	@Override
	protected void onCreate(Bundle
							savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main);
			editTextName = (EditText)findViewById
		(R.id.edit);
		wb=(WebView)findViewById(R.id.trial);
		

		buttonSubmit = (Button)findViewById(R.id.btn);
		buttonSubmit.setOnClickListener(new
			View.OnClickListener() {
				@Override
				public void onClick(View v) {
				    wb.getSettings().setJavaScriptEnabled(true);
					wb.getSettings().setAllowContentAccess(true);
					wb.getSettings().setUseWideViewPort(true);
					wb.getSettings().setLoadsImagesAutomatically(true);
					wb.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
					wb.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
					wb.getSettings().setEnableSmoothTransition(true);
					wb.getSettings().setDomStorageEnabled(true);
				
					wb.setWebViewClient(new WebViewClient(){
							public boolean shoulOverrideUrlLoading(WebView view, String url) {
								view.loadUrl(url);
								return super.shouldOverrideUrlLoading(view, url);
							}
						});
					wb.loadUrl("http://melkisuleman882.000webhostapp.com/console/csl.php");
					
		
					GetDataFromEditText();
					SendDataToServer(GetName)
						;
				}
			});
	}
	public void GetDataFromEditText(){
		GetName = editTextName.getText().toString();
		
	}
	public void SendDataToServer(final String code
								 ){
		class SendPostReqAsyncTask extends
		AsyncTask<String, Void, String> {
			@Override
			protected String doInBackground(String... params) {
				String QuickName = code ; // $_POST['code']
				
				List<NameValuePair> nameValuePairs = new
					ArrayList<NameValuePair>();
				nameValuePairs.add(new BasicNameValuePair
								   ("code", QuickName)); //code $_POST['code'];
				
				try {
					HttpClient httpClient = new DefaultHttpClient();
					HttpPost httpPost = new HttpPost(DataParseUrl);
					httpPost.setEntity(new UrlEncodedFormEntity
									   (nameValuePairs));
					HttpResponse response = httpClient.execute
					(httpPost);
					HttpEntity entity = response.getEntity();
				} catch (ClientProtocolException e) {
				} catch (IOException e) {
				}
				return "sending...";
			}
			@Override
			protected void onPostExecute(String result) {
				super.onPostExecute(result);
				Toast.makeText(MainActivity.this, "execute", Toast.LENGTH_LONG).show();
				
				
				}
		}
		SendPostReqAsyncTask sendPostReqAsyncTask =
			new SendPostReqAsyncTask();
		sendPostReqAsyncTask.execute(code
									 );
								
	}
	
	public void onBackPressed() {
        if(wb.canGoBack()){
            wb.goBack();
        }else{
            super.onBackPressed();
        }
    }
	public void move(View v){
		Intent i=new Intent(MainActivity.this,web2.class);
		startActivity(i);
	}
}

