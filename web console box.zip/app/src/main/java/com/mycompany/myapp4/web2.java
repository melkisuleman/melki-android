package com.mycompany.myapp4;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
public class web2 extends Activity {
	WebView wb;
		@Override
	protected void onCreate(Bundle
							savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.move);
		

			
			wb=(WebView)findViewById(R.id.wb2);


				wb.getSettings().setJavaScriptEnabled(true);
						wb.getSettings().setAllowContentAccess(true);
						wb.getSettings().setUseWideViewPort(true);
						wb.getSettings().setLoadsImagesAutomatically(true);
						wb.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
						wb.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
						wb.getSettings().setEnableSmoothTransition(true);
						wb.getSettings().setDomStorageEnabled(true);

						wb.setWebViewClient(new WebViewClient(){
								public boolean shoulOverrideUrlLoading(WebView view, String url) {
									view.loadUrl(url);
									return super.shouldOverrideUrlLoading(view, url);
								}
							});
						wb.loadUrl("http://melkisuleman882.000webhostapp.com/console/csl.php");}
					

	public void onBackPressed() {
        if(wb.canGoBack()){
            wb.goBack();
        }else{
            Intent i=new Intent(web2.this,MainActivity.class);
			startActivity(i);
        }}}
    



