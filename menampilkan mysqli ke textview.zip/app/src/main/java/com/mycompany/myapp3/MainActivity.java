package com.mycompany.myapp3;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.app.Activity;
import android.app.ProgressDialog;
public class MainActivity extends Activity {
	TextView txt;
	String result;
	private String NPM = "06.2009.1.04900";
	JSONParser jParser = new JSONParser();
	ArrayList<HashMap<String, String>> accountsList;
	JSONArray accounts = null;
	private static String base_url = "http://100video.000webhostapp.com/get.php";
	private ProgressDialog pDialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		    super.onCreate(savedInstanceState);
		    setContentView(R.layout.main);
		    txt=(TextView)findViewById(R.id.tampil);
		    new LoadProfile().execute();}
	        class LoadProfile extends AsyncTask<String, String, String>{
	        @Override
		    protected void onPreExecute()
		    {super.onPreExecute();
			pDialog = new ProgressDialog(MainActivity.this);
			pDialog.setMessage("Retrieving data. Please wait...");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(false);
			pDialog.show();}
			protected String doInBackground(String... args){
			List params=new ArrayList();
			params.add(new BasicNameValuePair("npm", NPM));
			JSONObject json=jParser.makeHttpRequest(base_url, "GET",params);
			Log.d("All Accounts: ", json.toString());
			try {
			accounts = json.getJSONArray("account");
		    for (int i = 0; i < accounts.length(); i++)
		    {JSONObject c = accounts.getJSONObject(i);
			result= (c.getString("npm"));}}			
			catch (JSONException e){
			e.printStackTrace();}
			return null;}
		    protected void onPostExecute(String file_url) {
			pDialog.dismiss();
			txt.setText(result);}}}
		
